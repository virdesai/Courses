#1
meal=44.50 #defining cost of the meal
#2
tax=.0675 #defining value of tax
#3
tip=.15 #defining tip percentage
#4
meal=meal+meal*tax #calculating the cost of the meal with tax
#5
total=meal+meal*tip #total cost of the meal after tip added to the taxed meal
#6
print total
